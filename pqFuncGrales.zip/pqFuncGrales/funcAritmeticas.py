# funcAritmeticas.py
# Módulo de funciones aritméticas

# Definimos que funciones estarán disponibles
__all__ = ["cuadrado", "doble","sistema"]

#Definiendo algunas variables del Modulo
sistema = "POS Ver 12.3"
version = 2.13


# Definimos la función factorial
def factorial(numero):	
	# Verifica si es 0 o 1
    if (numero==0 or numero==1):
        return 1;
	# Para cualquier otro numero usa recursividad	
    else:		
		# Retornamos
        return numero * factorial(numero-1);	
    
def cuadrado(numero): 
    return numero * numero

def doble(numero): 
    return numero * 2
	
# testing
if __name__ == '__main__':
    print (factorial(5))
    print (cuadrado(5))
    print (doble(5))
    print (sistema)
    print (version)
	

