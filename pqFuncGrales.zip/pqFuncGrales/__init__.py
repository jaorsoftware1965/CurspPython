# Archivo para definir el paquete pqFuncGrales
# No Contiene instrucción alguna y puede estar vacío